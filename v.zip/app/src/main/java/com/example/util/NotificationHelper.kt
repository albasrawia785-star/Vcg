package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.DebtApplication
import com.example.MainActivity
import com.example.data.model.OperationType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

object NotificationHelper {

    const val CHANNEL_ID = "debt_reminders_channel"
    const val NOTIFICATION_ID = 1001

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "تنبيهات الديون المستحقة"
            val descriptionText = "إشعارات للتذكير بالمدينين المتأخرين عن السداد"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun showNotification(context: Context, title: String, message: String) {
        createNotificationChannel(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent: PendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, builder.build())
        } catch (e: SecurityException) {
            // Permission missing
        }
    }

    suspend fun checkAndNotifyOverdueDebtors(context: Context): Int = withContext(Dispatchers.IO) {
        try {
            val app = context.applicationContext as? DebtApplication ?: return@withContext 0
            val db = app.database
            val settingsRepo = app.settingsRepository

            val threshold = settingsRepo.overdueDays.first()
            val customers = db.customerDao().getAllCustomers().first()
            val operationsWithCustomer = db.operationDao().getAllOperationsWithCustomer().first()

            val now = System.currentTimeMillis()
            val oneDayMs = 1000L * 60 * 60 * 24

            val lateCustomers = customers
                .filter { it.debtAmount > 0 }
                .mapNotNull { customer ->
                    val customerDebtOps = operationsWithCustomer
                        .map { it.operation }
                        .filter { it.customerId == customer.id && it.type == OperationType.DEBT }
                    val lastDebtTime = customerDebtOps.maxOfOrNull { it.dateTime }
                    if (lastDebtTime != null) {
                        val daysPassed = ((now - lastDebtTime) / oneDayMs).toInt().coerceAtLeast(0)
                        if (daysPassed > threshold) customer else null
                    } else null
                }

            if (lateCustomers.isNotEmpty()) {
                val count = lateCustomers.size
                val totalDebt = lateCustomers.sumOf { it.debtAmount }
                val firstCustomerName = lateCustomers.first().name

                val title = "🔔 تذكير بمواعيد السداد المستحقة"
                val message = if (count == 1) {
                    "المدين ($firstCustomerName) متأخر عن السداد بمبلغ ${totalDebt.formatCurrency()}."
                } else {
                    "يوجد $count مدينين متأخرين عن السداد (مثل: $firstCustomerName) بإجمالي: ${totalDebt.formatCurrency()}."
                }

                showNotification(context, title, message)
            }

            lateCustomers.size
        } catch (e: Exception) {
            android.util.Log.e("NotificationHelper", "checkAndNotifyOverdueDebtors exception", e)
            0
        }
    }
}
