package com.example

/**
 * ملف التكوين لتوافقية التطبيق (BabyConfig)
 * يوجه جميع القيم والبيانات مباشرة إلى كائن التحكم المركزي (Aldion)
 * لضمان أخذ جميع الإعدادات من ملف Aldion.kt حصراً.
 */
object BabyConfig {
    val USER_NAME get() = Aldion.USERNAME
    val APP_NAME get() = Aldion.SHOP_NAME
    val APP_SUBTITLE get() = "إدارة الديون والمدينين"
    val STORE_NAME get() = Aldion.SHOP_NAME
    val PHONE_NUMBER get() = Aldion.PHONE_NUMBER
    val CURRENCY get() = Aldion.CURRENCY
    val RECEIPT_FOOTER get() = Aldion.RECEIPT_FOOTER
    const val DEFAULT_PAPER_SIZE = "58mm"
    const val APP_VERSION = "1.0.0"
    val MAX_CUSTOMERS_FREE get() = Aldion.DEMO_MAX_CUSTOMERS
    val SUBSCRIPTION_MESSAGE get() = Aldion.SUBSCRIPTION_REQUIRED_MESSAGE
}

