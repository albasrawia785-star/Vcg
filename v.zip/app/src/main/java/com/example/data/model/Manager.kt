package com.example.data.model

data class Manager(
    val managerId: String = "",
    val shopId: String = "",
    val shopName: String = "",
    val username: String = "",
    val password: String = "",
    val phone: String = "",
    val role: String = "ADMIN", // "SUPER_ADMIN" or "ADMIN"
    val status: String = "ACTIVE", // "ACTIVE" or "DISABLED" ("نشط" or "معطل")
    val createdAt: Long = System.currentTimeMillis(),
    val lastLogin: Long = System.currentTimeMillis()
) {
    fun isActive(): Boolean {
        return status.equals("ACTIVE", ignoreCase = true) || status == "نشط"
    }

    fun isSuperAdmin(): Boolean {
        return role.equals("SUPER_ADMIN", ignoreCase = true)
    }
}
