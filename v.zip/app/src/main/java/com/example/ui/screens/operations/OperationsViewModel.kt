package com.example.ui.screens.operations

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Customer
import com.example.data.model.OperationWithCustomer
import com.example.data.repository.DebtRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class OperationsViewModel(
    private val repository: DebtRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCustomer = MutableStateFlow<Customer?>(null)
    val selectedCustomer: StateFlow<Customer?> = _selectedCustomer.asStateFlow()

    val customers: StateFlow<List<Customer>> = repository.allCustomers
        .stateIn(
            scope = viewModelScope,
            started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val operations: StateFlow<List<OperationWithCustomer>> = combine(
        repository.allOperationsWithCustomer,
        _searchQuery,
        _selectedCustomer
    ) { list, query, selectedCust ->
        var filtered = list

        if (selectedCust != null) {
            filtered = filtered.filter { it.operation.customerId == selectedCust.id }
        }

        if (query.isNotBlank()) {
            val q = query.trim()
            filtered = filtered.filter { opWithCust ->
                opWithCust.customer?.name?.contains(q, ignoreCase = true) == true ||
                opWithCust.operation.note.contains(q, ignoreCase = true)
            }
        }

        filtered
    }.stateIn(
        scope = viewModelScope,
        started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _uiEvent = MutableSharedFlow<String>()
    val uiEvent: SharedFlow<String> = _uiEvent.asSharedFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCustomer(customer: Customer?) {
        _selectedCustomer.value = customer
    }

    fun deleteOperation(opWithCustomer: OperationWithCustomer) {
        viewModelScope.launch {
            val result = repository.deleteOperation(opWithCustomer)
            result.onSuccess {
                _uiEvent.emit("تم حذف العملية وإعادة احتساب ديون المدين بنجاح")
            }.onFailure { e ->
                _uiEvent.emit("فشل حذف العملية: ${e.message}")
            }
        }
    }

    class Factory(
        private val repository: DebtRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return OperationsViewModel(repository) as T
        }
    }
}

